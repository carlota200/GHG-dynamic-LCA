
#MultiGLOW.PY - Multimodel GLObal Warming Potencial dYnamic and Static v1.0 alpha
#@Carla Silva
#IDL-Energy Transition Research Group
#Version alpha for improvement
a0=0.217 #CO2 decay parameters by default Bern 378ppm model
a1 = 0.259
a2=0.338
a3=0.186
tau1=172.9
tau2=18.51
tau3=1.186
# radiative forcing-RF- Watt per square meter and per kg of substance in the atmosphere
RFCO2=1.77e-15
RFCH4=66*RFCO2
RFN2O=200*RFCO2

#time of operation(years)-TO
TO=30
#CO2 background concentration (ppm)-CO2back
CO2back= 378
#CH4 lifetime (years) CH4LT
CH4LT= 12
#N2O lifetime
N2OLT= 114
#TH:Time horizon
TH= 100

#define models matrix

import numpy as np



M = np.array([[2.94E-7, 0.3665, 0.3542, 0.2793, 1691, 28.36, 5.316],
    [0.434, 0.1973, 0.1889, 0.1789, 23.07, 23.07, 3.922],
    [1.25E-7,0.5864, 0.231, 0.231, 178.1, 9.039, 8.989],
    [6.35e-10,0.515, 0.2631, 0.2219, 1955, 45.83, 3.872],
    [0.1266,0.2607, 0.2909, 0.3218, 302.8, 31.61, 4.24],
    [0.1332,0.1663, 0.3453, 0.3551,313.3, 29.99, 4.601],
    [6.35e-10,0.515, 0.2631, 0.2219, 1955.5, 45.83, 3.872],
    [0.2123,0.2444, 0.336, 0.2073, 0.2219, 1955, 45.83],
    [0.2796,0.2382, 0.2382, 0.244, 276.2, 38.45, 4.928],
    [0.2362,0.09866, 0.385, 0.2801, 232.1, 58.5, 2.587],
    [0.1994,0.1762, 0.3452, 0.2792, 333.1, 39.69, 4.11],
    [0.2318,0.2756, 0.49, 0.002576, 272.6, 6.692, 6.692],
    [0.2145,0.249, 0.1924, 0.3441, 270.1, 39.32, 4.305],
    [8.54,0.3606, 0.4503, 0.1891, 1596, 21.71, 2.281],
    [0.2848,0.2938, 0.2382, 0.1831, 454.3, 25, 2.014],
    [0.3186,0.1748, 0.1921, 0.3145, 304.6, 26.56, 3.8],
    [0.1779,0.1654, 0.3796, 0.2772, 386.2, 36.89, 3.723],
    [0.2051,0.2533, 0.3318, 0.2098, 596.1, 21.97, 2.995],
    [7.18e-6,0.2032, 0.6995, 0.09738, 85770, 111.8, 0.01583],
    [0.2173,0.224, 0.2824, 0.2763, 394.4, 36.54, 4.304],])
#  First element of first row

print("M[0][0] =", M[0][0])
print(M[-1][-1])#last element of the matrix

import math #CO2eq cLCA, dLCA
for i in range(0,TH,1):
  decayCH4=math.exp(-i/CH4LT)*RFCH4 #W/m2/kg
  print(decayCH4)
#read static inventory 1 line CO2(kg), CH4 kg), N2O (kg) into a matrix
#matrix_Static = open ("StaticInventory.txt").read()
list_of_lists = []

with open('StaticInventory.txt') as f:
    for line in f:
        inner_list = [elt.strip() for elt in line.split(' ')]
        list_of_lists.append(inner_list)

matrix_Static =np.array(list_of_lists,float)#transform list into an array with numpy
#print(matrix_Static[0,0])
time=0#first year operation
#CO2 pulse
pulseCO2 = []
pulseCH4=[]
pulseN2O=[]
co2 = matrix_Static[0, 0] * TO
ch4=matrix_Static[0,1]*TO
n2o=matrix_Static[0,2]*TO
pulseCO2.append(co2)
pulseCH4.append(ch4)
pulseN2O.append(n2o)
while time < TH:
    time=time+1
    co2=0
    ch4=0
    n2o=0
    pulseCO2.append(co2)
    pulseCH4.append(ch4)
    pulseN2O.append(n2o)
CO2matrix = np.zeros(shape=(101,101))
CH4matrix = np.zeros(shape=(101,101))
N2Omatrix=np.zeros(shape=(101,101))
refCO2=np.zeros(shape=(101,1))

#built CO2 matrix w/m2
for j in range(0,TH+1,1):
    time = 0
    for i in range(j,TH+1,1):
        CO2matrix[i,j]= pulseCO2[j] * (a0 + a1 * math.exp(-time / tau1) + a2 * math.exp(-time / tau2) + a3 * math.exp(-time / tau3))*RFCO2
        CH4matrix[i,j]=pulseCH4[j]*math.exp(-time / CH4LT) * RFCH4
        N2Omatrix[i,j]=pulseN2O[j]*math.exp(-time/N2OLT)*RFN2O
        time=time+1
time=0
for i in range(0,TH+1,1):
    refCO2[i,0]= (a0 + a1 * math.exp(-time / tau1) + a2 * math.exp(-time / tau2) + a3 * math.exp(-time / tau3))*RFCO2
    time=time+1
#build instantaneous radiative forcing W/m2
#cumulative radiative forcing W/m2
#CO2eq in relation to 1 kg pulse time 0

IRFCO2_cLCA=CO2matrix.sum(axis=1)
IRFCH4_cLCA=CH4matrix.sum(axis=1)
IRFN2O_cLCA=N2Omatrix.sum(axis=1)
reference=np.cumsum(refCO2)

IRF_cLCA=IRFCO2_cLCA+IRFCH4_cLCA+IRFN2O_cLCA
cumRF_cLCA=np.cumsum(IRF_cLCA)
CO2eq_cLCA=cumRF_cLCA/reference

#static inventory, const inventory overtime
#dynamic LCA dLCA
time=0#first year operation
#CO2 pulse
pulseCO2 = []
pulseCH4=[]
pulseN2O=[]
co2 = matrix_Static[0, 0]
ch4=matrix_Static[0,1]
n2o=matrix_Static[0,2]
pulseCO2.append(co2)
pulseCH4.append(ch4)
pulseN2O.append(n2o)
while time < TO-1:
    time=time+1
    pulseCO2.append(co2)
    pulseCH4.append(ch4)
    pulseN2O.append(n2o)

while time <TH+1 and time>TO-2:
    time = time + 1
    co2=0
    ch4=0
    n2o=0
    pulseCO2.append(co2)
    pulseCH4.append(ch4)
    pulseN2O.append(n2o)

CO2matrix = np.zeros(shape=(101,101))
CH4matrix = np.zeros(shape=(101,101))
N2Omatrix=np.zeros(shape=(101,101))


#built CO2 matrix w/m2
for j in range(0,TH+1,1):
    time = 0
    for i in range(j,TH+1,1):
        CO2matrix[i,j]= pulseCO2[j] * (a0 + a1 * math.exp(-time / tau1) + a2 * math.exp(-time / tau2) + a3 * math.exp(-time / tau3))*RFCO2
        CH4matrix[i,j]=pulseCH4[j]*math.exp(-time / CH4LT) * RFCH4
        N2Omatrix[i,j]=pulseN2O[j]*math.exp(-time/N2OLT)*RFN2O


        time=time+1

#build instantaneous radiative forcing W/m2
#cumulative radiative forcing W/m2
#CO2eq in relation to 1 kg pulse time 0

IRFCO2_dLCA=CO2matrix.sum(axis=1)
IRFCH4_dLCA=CH4matrix.sum(axis=1)
IRFN2O_dLCA=N2Omatrix.sum(axis=1)


IRF_dLCA=IRFCO2_dLCA+IRFCH4_dLCA+IRFN2O_dLCA #instantaneous radiative forcing
cumRF_dLCA=np.cumsum(IRF_dLCA) #cumulative radiative forcing
CO2eq_dLCA=cumRF_dLCA/reference #global warming potencial

import matplotlib.pyplot as plt



list_of_lists=[]#voltar a esvaziar esta lista
#read dynamic inventory multiple lines time (year), CO2 (kg), CH4 (kg), N2O (kg)
with open('DynamicInventory.txt') as f:
    for line in f:
        inner_list = [elt.strip() for elt in line.split(' ')]
        list_of_lists.append(inner_list)

matrix_Dynamic =np.array(list_of_lists,float)#transform list into an array with numpy

Lines=np.size(matrix_Dynamic,0)#identify the number of lines of dynamic inventory file
Columns=np.size(matrix_Dynamic,1)#identify the number of columns of dynamic inventory file

pulseCO2 = []
pulseCH4=[]
pulseN2O=[]
time=[]
n=0
while n<Lines:
    t= matrix_Dynamic[n,0]
    co2 = matrix_Dynamic[n,1]
    ch4 = matrix_Dynamic[n,2]
    n2o = matrix_Dynamic[n,3]
    time.append(t)
    pulseCO2.append(co2)
    pulseCH4.append(ch4)
    pulseN2O.append(n2o)
    ultimoTempo=time[n]
    n=n+1
t=n
while ultimoTempo < TH:
    co2=0
    ch4=0
    n2o=0
    ultimoTempo=ultimoTempo+1
    pulseCO2.append(co2)
    pulseCH4.append(ch4)
    pulseN2O.append(n2o)
    time.append(ultimoTempo)
    t = t + 1

Lines=t#identify the number of lines
CO2matrix = np.zeros(shape=(Lines+1,Lines+1))
CH4matrix = np.zeros(shape=(Lines+1,Lines+1))
N2Omatrix = np.zeros(shape=(Lines+1,Lines+1))
time=np.array(time,float)


#built CO2 matrix w/m2
for j in range(0,Lines,1):
    z = 0
    for i in range(j,Lines,1):
        CO2matrix[i,j]= pulseCO2[j] * (a0 + a1 * math.exp(-time[z] / tau1) + a2 * math.exp(-time[z] / tau2) + a3 * math.exp(-time[z] / tau3))*RFCO2
        CH4matrix[i,j]=pulseCH4[j]*math.exp(-time[z] / CH4LT) * RFCH4
        N2Omatrix[i,j]=pulseN2O[j]*math.exp(-time[z]/N2OLT)*RFN2O
        z=z+1

#build instantaneous radiative forcing W/m2
#cumulative radiative forcing W/m2
#CO2eq in relation to 1 kg pulse time 0
refCO2=np.zeros(shape=(Lines,1))
z = 0
for j in range(0,Lines,1):
    refCO2[j, 0] = (a0 + a1 * math.exp(-time[z] / tau1) + a2 * math.exp(-time[z] / tau2) + a3 * math.exp(-time [z] / tau3)) * RFCO2
    z=z+1


IRFCO2_dLCA_dinventory=CO2matrix.sum(axis=1)
IRFCH4_dLCA_dinventory=CH4matrix.sum(axis=1)
IRFN2O_dLCA_dinventory=N2Omatrix.sum(axis=1)



IRF_dLCA_dinventory=IRFCO2_dLCA_dinventory+IRFCH4_dLCA_dinventory+IRFN2O_dLCA_dinventory #instantaneous radiative forcing
# z=0
# w=0
# v=0
# for i in range(0,Lines+1,1):
cumRF_dLCA_dinventory=np.zeros(shape=(Lines))
CO2eq_dLCA_dinventory=np.zeros(shape=(Lines))
reference=np.zeros(shape=(Lines))
z=0
w=0
for j in range(0,Lines-1,1):
        cumRF_dLCA_dinventory[j]=(IRF_dLCA_dinventory[j]+ IRF_dLCA_dinventory[j+1])/2*(time[j+1]-time[j])+z
        z=cumRF_dLCA_dinventory[j] #cumulative radiative forcing
        reference[j]=refCO2[j, 0]+w
        w=reference[j]
        CO2eq_dLCA_dinventory[j]=cumRF_dLCA_dinventory[j]/reference[j] #global warming potencial

# Data for plotting
t = np.arange(0.0, 101.0, 1)
t2=time
#decayCH4=np.exp(-t/CH4LT)

fig, ax = plt.subplots()
ax.plot(t, CO2eq_dLCA, 'r--', t,CO2eq_cLCA,'bs', t2,CO2eq_dLCA_dinventory,'g^') #red -- and blue squares s

ax.set(xlabel='time (years)', ylabel='CO2eq (kg)',
       title='cLCA vs dLCA')
ax.grid()

fig.savefig("test.png")
plt.show()








#write to a txt file
#file = open ("StaticInventory.txt","w")
#matrix_Static
#file.close()
# import numpy as np
#matrix_Static=[2,3,4]
# np.savetxt('file.out', matrix_Static, delimiter=',')
with open('file.out', 'w') as f:
    f.write("MultiGlow v1.0.alpha\n")
    f.write("\n")
    f.write("\n")
    for item in matrix_Static:
        f.write("%s " % item)
    f.write("\n")
    f.write("\n")
    f.write("Time horizon = %f years" %TH)
