
list_of_lists = []

with open('StaticInventory.txt') as f:
    for line in f:
        inner_list = [elt.strip() for elt in line.split(' ')]
        list_of_lists.append(inner_list)

CO2= int(list_of_lists[1][1])
print(CO2)